#include "default.h"

extern u32 cp1251toUtf32[256];
extern const string encPath;

void loadEnc(const char* file);

